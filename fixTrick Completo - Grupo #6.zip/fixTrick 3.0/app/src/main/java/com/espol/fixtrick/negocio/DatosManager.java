package com.espol.fixtrick.negocio;

import android.content.Context;
import com.espol.fixtrick.Cliente.modelo.Cliente;
import com.espol.fixtrick.Cliente.modelo.TipoCliente;
import com.espol.fixtrick.Tecnico.modeloTec.Tecnico;
import com.espol.fixtrick.ordenes.Orden;
import com.espol.fixtrick.ordenes.OrdenStorage;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Clase intermediaria que carga y prepara los datos para los módulos de facturación y reportes.
 * "Parcha" las órdenes en memoria para vincularlas con Clientes y Técnicos.
 */
public class DatosManager {

    private static List<OrdenParcheada> ordenesParcheadas;
    private static List<Cliente> clientes;
    private static List<Tecnico> tecnicos;

    // Se debe llamar una vez al iniciar la app o la sección.
    public static void inicializar(Context context) {
        // Cargar las listas originales
        List<Orden> ordenesOriginales = OrdenStorage.cargarOrdenes(context);
        clientes = Cliente.obtenerClientes(); // Usamos la lista estática simple
        tecnicos = Tecnico.obtenerTecnicos();

        // Crear un mapa de clientes por nombre normalizado para búsqueda rápida
        Map<String, Cliente> mapaClientes = clientes.stream()
                .collect(Collectors.toMap(c -> normalizar(c.getNombre()), Function.identity(), (c1, c2) -> c1));

        // "Parchar" las órdenes
        ordenesParcheadas = new ArrayList<>();
        Random random = new Random();

        for (Orden orden : ordenesOriginales) {
            // 1. Vincular Cliente
            Cliente clienteVinculado = mapaClientes.get(normalizar(orden.getNombreCliente()));

            // 2. Vincular Técnico (Como no hay datos, se asigna uno aleatoriamente)
            Tecnico tecnicoAsignado = tecnicos.get(random.nextInt(tecnicos.size()));

            // 3. Crear la nueva Orden "Parcheada" con toda la información
            ordenesParcheadas.add(new OrdenParcheada(orden, clienteVinculado, tecnicoAsignado));
        }
    }

    public static List<OrdenParcheada> getOrdenesParcheadas() {
        return ordenesParcheadas != null ? ordenesParcheadas : new ArrayList<>();
    }

    public static List<Cliente> getClientes() {
        return clientes != null ? clientes : new ArrayList<>();
    }

    public static List<Cliente> getClientesEmpresariales() {
        if (clientes == null) return new ArrayList<>();
        List<Cliente> empresariales = new ArrayList<>();
        for (Cliente c : clientes) {
            if (c.getTipoCliente() == TipoCliente.EMPRESARIAL) {
                empresariales.add(c);
            }
        }
        return empresariales;
    }

    private static String normalizar(String s) {
        if (s == null) return "";
        String nfd = Normalizer.normalize(s.trim().toLowerCase(Locale.ROOT), Normalizer.Form.NFD);
        return nfd.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }
}
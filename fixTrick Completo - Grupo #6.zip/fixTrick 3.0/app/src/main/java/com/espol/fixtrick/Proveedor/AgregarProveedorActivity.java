package com.espol.fixtrick.Proveedor;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.espol.fixtrick.Proveedor.modeloProv.Proveedor;
import com.espol.fixtrick.R;

public class AgregarProveedorActivity extends AppCompatActivity {

    EditText etID, etNombre, etTelefono, etDescripcion;
    Button btnGuardarProv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_proveedor);

        etID = findViewById(R.id.etIdProv);
        int siguienteId = Proveedor.ultimoIdProv + 1;
        etID.setText(String.valueOf(siguienteId));
        etNombre = findViewById(R.id.etNombreProv);
        etTelefono = findViewById(R.id.etTelefonoProv);
        etDescripcion = findViewById(R.id.etDescripcionProv);
        btnGuardarProv = findViewById(R.id.btnGuardarProv);

        btnGuardarProv.setOnClickListener(v -> {
            String nombre = etNombre.getText().toString().trim();
            String telStr = etTelefono.getText().toString().trim();
            String descripcion = etDescripcion.getText().toString().trim();

            if (nombre.isEmpty() || telStr.isEmpty() || descripcion.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
                return;
            }

            int telefono;
            try {
                telefono = Integer.parseInt(telStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Teléfono inválido", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent resultado = new Intent();
            resultado.putExtra("nombre", nombre);
            resultado.putExtra("telefono", telefono);
            resultado.putExtra("descripcion", descripcion);

            setResult(RESULT_OK, resultado);
            finish(); // cerrar esta pantalla

        });
    }
}
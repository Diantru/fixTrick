
package com.espol.fixtrick.ordenes;

import com.espol.fixtrick.Cliente.modelo.Cliente;
import com.espol.fixtrick.Tecnico.modeloTec.Tecnico;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class Orden implements Serializable {
    private int id;
    private String nombreCliente;
    private String descripcion;
    private Date fecha;
    private String placa;
    private List<ServicioConCantidad> servicios;
    private double total;

    private Cliente clienteObj; // Para identificar al cliente correctamente
    private Tecnico tecnicoObj; // Para saber qué técnico realizó la orden

    public Orden(int id, String nombreCliente, String descripcion, Date fecha, String placa,
                 List<ServicioConCantidad> servicios) {
        this.id = id;
        this.nombreCliente = nombreCliente;
        this.descripcion = descripcion;
        this.fecha = fecha;
        this.placa = placa;
        this.servicios = servicios;
        this.total = calcularTotal(servicios);
    }

    public Orden(int id, String nombreCliente, String descripcion, Date fecha, String placa,
                 List<ServicioConCantidad> servicios, Cliente clienteObj, Tecnico tecnicoObj) {
        this(id, nombreCliente, descripcion, fecha, placa, servicios); // Llama al constructor original
        this.clienteObj = clienteObj;
        this.tecnicoObj = tecnicoObj;
    }

    public static double calcularTotal(List<ServicioConCantidad> servicios) {
        if (servicios == null) return 0.0;
        double t = 0;
        for (ServicioConCantidad s : servicios) t += s.getSubtotal();
        return t;
    }

    // --- Getters y Setters ---
    public int getId() { return id; }
    public String getNombreCliente() { return nombreCliente; }
    public String getDescripcion() { return descripcion; }
    public Date getFecha() { return fecha; }
    public String getPlaca() { return placa; }
    public List<ServicioConCantidad> getServicios() { return servicios; }
    public double getTotal() { return total; }

    public Cliente getClienteObj() { return clienteObj; }
    public Tecnico getTecnicoObj() { return tecnicoObj; }

    public void setClienteObj(Cliente clienteObj) { this.clienteObj = clienteObj; }
    public void setTecnicoObj(Tecnico tecnicoObj) { this.tecnicoObj = tecnicoObj; }
}
package com.espol.fixtrick.Tecnico;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.espol.fixtrick.R;
import com.espol.fixtrick.Tecnico.modeloTec.Tecnico;


public class AgregarTecnico extends AppCompatActivity {

    EditText etId, etNombre, etTelefono, etEspecialidad;
    Button btnGuardarTec;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_tecnico);

        etId = findViewById(R.id.etIdTec);
        int siguienteId = Tecnico.ultimoIdTec + 1;
        etId.setText(String.valueOf(siguienteId));
        etNombre = findViewById(R.id.etNombreTec);
        etTelefono = findViewById(R.id.etTelefonoTec);
        etEspecialidad = findViewById(R.id.etEspecialidadTec);
        btnGuardarTec = findViewById(R.id.btnGuardarTec);

        btnGuardarTec.setOnClickListener(v -> {
            String nombre = etNombre.getText().toString().trim();
            String telStr = etTelefono.getText().toString().trim();
            String especialidad = etEspecialidad.getText().toString().trim();

            if (nombre.isEmpty() || telStr.isEmpty() || especialidad.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
                return;
            }

            int telefono;
            try {
                telefono = Integer.parseInt(telStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Teléfono inválido", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent resultado = new Intent();
            resultado.putExtra("nombre", nombre);
            resultado.putExtra("telefono", telefono);
            resultado.putExtra("especialidad", especialidad);

            setResult(RESULT_OK, resultado);
            finish(); // cerrar esta pantalla

        });
    }
}
package com.espol.fixtrick.ordenes;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.espol.fixtrick.R;
import java.util.ArrayList;
import java.util.List;

public class OrdenesActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<Orden> ordenes = new ArrayList<>();
    private OrdenAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ordenes);

        recyclerView = findViewById(R.id.recyclerOrdenes);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //crea 1 orden solo para Juan Perez, Maria Rodriguez y Pedro Gomez
        OrdenStorage.asegurarOrdenesPorDefecto(this);

        ordenes.addAll(OrdenStorage.cargarOrdenes(this));

        adapter = new OrdenAdapter(ordenes, orden -> {
            startActivity(new Intent(this, DetalleOrdenActivity.class).putExtra("orden", orden));
        });
        recyclerView.setAdapter(adapter);

        Button btnCrearOrden = findViewById(R.id.btnCrearOrden);
        btnCrearOrden.setOnClickListener(v ->
                startActivity(new Intent(this, CrearOrdenActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        ordenes.clear();
        ordenes.addAll(OrdenStorage.cargarOrdenes(this));
        adapter.notifyDataSetChanged();
    }
}

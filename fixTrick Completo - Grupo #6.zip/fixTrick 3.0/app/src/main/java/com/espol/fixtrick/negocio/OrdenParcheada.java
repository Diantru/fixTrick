package com.espol.fixtrick.negocio;

import com.espol.fixtrick.Cliente.modelo.Cliente;
import com.espol.fixtrick.Tecnico.modeloTec.Tecnico;
import com.espol.fixtrick.ordenes.Orden;
import com.espol.fixtrick.ordenes.ServicioConCantidad;
import java.util.Date;
import java.util.List;

/**
 * Wrapper para la clase Orden que contiene la info faltante (Cliente y Tecnico).
 */
public class OrdenParcheada {
    private Orden ordenOriginal;
    private Cliente cliente;
    private Tecnico tecnico;

    public OrdenParcheada(Orden ordenOriginal, Cliente cliente, Tecnico tecnico) {
        this.ordenOriginal = ordenOriginal;
        this.cliente = cliente;
        this.tecnico = tecnico;
    }

    // Getters para la información nueva
    public Cliente getCliente() { return cliente; }
    public Tecnico getTecnico() { return tecnico; }

    // Getters delegados a la orden original
    public Date getFecha() { return ordenOriginal.getFecha(); }
    public double getTotal() { return ordenOriginal.getTotal(); }
    public List<ServicioConCantidad> getServicios() { return ordenOriginal.getServicios(); }
}
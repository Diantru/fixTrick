package com.espol.fixtrick.ordenes;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import com.espol.fixtrick.R;
import com.espol.fixtrick.Cliente.modelo.Cliente;
import com.espol.fixtrick.administrarServicios.Servicio;

import java.text.SimpleDateFormat;
import java.util.*;

public class CrearOrdenActivity extends AppCompatActivity {

    private Spinner spClientes, spTipoVehiculo, spServicios;
    private EditText etIdCliente, etFecha, etPlaca, etCantidad;
    private Button btnAgregarServicio, btnGuardar;
    private LinearLayout layoutServiciosAgregados;
    private TextView tvTotal;

    private List<Cliente> clientes;
    private ArrayList<Servicio> servicios;
    private final List<ServicioConCantidad> serviciosSeleccionados = new ArrayList<>();

    private double total = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_orden);

        spClientes = findViewById(R.id.spClientes);
        spTipoVehiculo = findViewById(R.id.spTipoVehiculo);
        spServicios = findViewById(R.id.spServicios);
        etIdCliente = findViewById(R.id.etIdCliente);
        etFecha = findViewById(R.id.etFecha);
        etPlaca = findViewById(R.id.etPlaca);
        etCantidad = findViewById(R.id.etCantidad);
        btnAgregarServicio = findViewById(R.id.btnAgregarServicio);
        btnGuardar = findViewById(R.id.btnGuardarOrden);
        layoutServiciosAgregados = findViewById(R.id.layoutServiciosAgregados);
        tvTotal = findViewById(R.id.tvTotal);

        cargarClientesYServicios();

        ArrayAdapter<String> tiposAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                Arrays.asList("-- Seleccionar --", "Turismo", "Deportivo", "Furgoneta"));
        tiposAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spTipoVehiculo.setAdapter(tiposAdapter);

        etFecha.setOnClickListener(v -> mostrarDatePicker());
        btnAgregarServicio.setOnClickListener(v -> agregarServicioSeleccionado());
        btnGuardar.setOnClickListener(v -> guardarOrden());
        actualizarTotal();
    }

    private void cargarClientesYServicios() {

        try {
            clientes = com.espol.fixtrick.Cliente.modelo.Cliente
                    .cargarClientes(getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS));
        } catch (Exception e) { clientes = null; }

        if (clientes == null || clientes.isEmpty()) {
            try { clientes = com.espol.fixtrick.Cliente.modelo.Cliente.obtenerClientes(); }
            catch (Throwable ignore) { clientes = new ArrayList<>(); }
        }

        try {
            Servicio.crearDatosIniciales(getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS));
            servicios = Servicio.cargarServicios(getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS));
        } catch (Exception e) {
            servicios = new ArrayList<>();
        }

        // Spinner clientes
        List<String> nombres = new ArrayList<>();
        nombres.add("-- Seleccionar cliente --");
        if (clientes != null) for (Cliente c : clientes) nombres.add(c.getNombre());
        ArrayAdapter<String> adapterCli = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, nombres);
        adapterCli.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spClientes.setAdapter(adapterCli);

        // Spinner servicios
        List<String> nombresServ = new ArrayList<>();
        nombresServ.add("-- Servicio --");
        if (servicios != null) for (Servicio s : servicios) nombresServ.add(s.getNombre() + " ($" + s.getPrecio() + ")");
        ArrayAdapter<String> adapterServ = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, nombresServ);
        adapterServ.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spServicios.setAdapter(adapterServ);
    }

    private void mostrarDatePicker() {
        Calendar c = Calendar.getInstance();
        DatePickerDialog dp = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            Calendar sel = Calendar.getInstance();
            sel.set(year, month, dayOfMonth);
            etFecha.setText(new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(sel.getTime()));
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dp.show();
    }

    private void agregarServicioSeleccionado() {
        int pos = spServicios.getSelectedItemPosition() - 1;
        if (pos < 0 || pos >= servicios.size()) {
            Toast.makeText(this, "Seleccione un servicio", Toast.LENGTH_SHORT).show();
            return;
        }
        String qtyS = etCantidad.getText().toString().trim();
        if (qtyS.isEmpty()) {
            Toast.makeText(this, "Ingrese cantidad", Toast.LENGTH_SHORT).show();
            return;
        }
        int qty = Integer.parseInt(qtyS);
        Servicio s = servicios.get(pos);
        ServicioConCantidad sc = new ServicioConCantidad(s, qty);
        serviciosSeleccionados.add(sc);

        View v = getLayoutInflater().inflate(R.layout.item_orden_servicio, layoutServiciosAgregados, false);
        TextView tvNom = v.findViewById(R.id.tvNombreServicio);
        TextView tvQty = v.findViewById(R.id.tvCantidadServicio);
        TextView tvSub = v.findViewById(R.id.tvSubtotalServicio);
        tvNom.setText(sc.getNombre());
        tvQty.setText("Cantidad: " + sc.getCantidad());
        tvSub.setText("Subtotal: $" + String.format(Locale.getDefault(), "%.2f", sc.getSubtotal()));
        layoutServiciosAgregados.addView(v);

        actualizarTotal();
        etCantidad.setText("");
    }

    private void actualizarTotal() {
        total = 0;
        for (ServicioConCantidad s : serviciosSeleccionados) total += s.getSubtotal();
        tvTotal.setText("Total: $" + String.format(Locale.getDefault(), "%.2f", total));
    }

    private void guardarOrden() {
        int posCli = spClientes.getSelectedItemPosition() - 1;
        if (posCli < 0 || posCli >= clientes.size()) {
            Toast.makeText(this, "Seleccione cliente", Toast.LENGTH_SHORT).show();
            return;
        }
        if (serviciosSeleccionados.isEmpty()) {
            Toast.makeText(this, "Agregue al menos un servicio", Toast.LENGTH_SHORT).show();
            return;
        }
        Cliente c = clientes.get(posCli);
        String fechaTxt = etFecha.getText().toString().trim();
        Date fecha = new Date();
        try {
            fecha = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).parse(fechaTxt);
        } catch (Exception ignored) {}

        String placa = etPlaca.getText().toString().trim();
        int nuevoId = new Random().nextInt(100000);

        Orden orden = new Orden(nuevoId, c.getNombre(), "Orden creada", fecha, placa, serviciosSeleccionados);

        List<Orden> actuales = OrdenStorage.cargarOrdenes(this);
        actuales.add(0, orden);
        OrdenStorage.guardarOrdenes(this, actuales);

        Toast.makeText(this, "Orden guardada", Toast.LENGTH_SHORT).show();
        finish();
    }
}

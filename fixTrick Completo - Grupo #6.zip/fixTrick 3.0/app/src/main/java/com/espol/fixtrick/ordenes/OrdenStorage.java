package com.espol.fixtrick.ordenes;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;

import com.espol.fixtrick.Cliente.modelo.Cliente;
import com.espol.fixtrick.administrarServicios.Servicio;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.Normalizer;
import java.util.*;

public class OrdenStorage {
    private static final String FILE_NAME = "ordenes.dat";

    // Flag para sembrar una sola vez
    private static final String PREFS_NAME = "orden_prefs";
    private static final String PREF_KEY_SEEDED = "defaults_seeded_v8";

    private static final Set<String> PRIMEROS_NOMBRES_DEFECTO = new HashSet<>(Arrays.asList(
            "juan", "maria", "pedro"
    ));

    public static List<Orden> cargarOrdenes(Context context) {
        List<Orden> ordenes = leerOrdenesArchivo(context);
        return repararOrdenesIncompletas(ordenes);
    }

    public static void asegurarOrdenesPorDefecto(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (sp.getBoolean(PREF_KEY_SEEDED, false)) return;

        List<Orden> ordenes = leerOrdenesArchivo(context);

        Set<String> nombresConOrden = new HashSet<>();
        Set<Integer> idsUsados = new HashSet<>();
        for (Orden o : ordenes) {
            if (o.getNombreCliente() != null)
                nombresConOrden.add(normaliza(o.getNombreCliente()));
            idsUsados.add(o.getId());
        }

        File ext = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        List<Cliente> clientes;
        try { clientes = Cliente.cargarClientes(ext); }
        catch (Exception e) { clientes = new ArrayList<>(); }
        if (clientes == null || clientes.isEmpty()) {
            try { clientes = Cliente.obtenerClientes(); } catch (Throwable t) { clientes = new ArrayList<>(); }
        }

        try { Servicio.crearDatosIniciales(ext); } catch (Exception ignored) {}
        ArrayList<Servicio> servicios;
        try { servicios = Servicio.cargarServicios(ext); }
        catch (Exception e) { servicios = new ArrayList<>(); }
        if (servicios.isEmpty()) return;

        Map<String, Cliente> candidatos = new LinkedHashMap<>();
        for (Cliente c : clientes) {
            if (c == null || c.getNombre() == null) continue;
            String nombreNorm = normaliza(c.getNombre());
            String primer = obtenerPrimerNombre(nombreNorm);
            if (PRIMEROS_NOMBRES_DEFECTO.contains(primer)) {
                candidatos.putIfAbsent(nombreNorm, c);
            }
        }

        boolean agrego = false;
        Random rnd = new Random();

        for (Map.Entry<String, Cliente> e : candidatos.entrySet()) {
            String nombreNorm = e.getKey();
            Cliente c = e.getValue();
            if (nombresConOrden.contains(nombreNorm)) continue;

            ArrayList<Servicio> copia = new ArrayList<>(servicios);
            Collections.shuffle(copia, rnd);
            int cuantos = 1 + rnd.nextInt(Math.min(4, copia.size()));
            List<ServicioConCantidad> seleccion = new ArrayList<>();
            for (int i = 0; i < cuantos; i++) {
                Servicio s = copia.get(i);
                int qty = 1 + rnd.nextInt(3);
                seleccion.add(new ServicioConCantidad(s, qty));
            }

            int id = generarIdUnico(rnd, idsUsados);
            String placa = generarPlacaAleatoria(rnd);
            Date fecha = generarFechaAleatoria(rnd);
            ordenes.add(0, new Orden(id, c.getNombre(), "Orden generada automática", fecha, placa, seleccion));
            agrego = true;
        }

        if (agrego) {
            guardarOrdenes(context, ordenes);
            sp.edit().putBoolean(PREF_KEY_SEEDED, true).apply();
        }
    }

    private static String normaliza(String s) {
        if (s == null) return "";
        String nfd = Normalizer.normalize(s.trim().toLowerCase(Locale.ROOT), Normalizer.Form.NFD);
        return nfd.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }
    private static String obtenerPrimerNombre(String nombreCompletoNorm) {
        if (nombreCompletoNorm.isEmpty()) return "";
        String[] p = nombreCompletoNorm.split("\\s+");
        return p.length == 0 ? "" : p[0];
    }

    public static void guardarOrdenes(Context context, List<Orden> ordenes) {
        try (FileOutputStream fos = context.openFileOutput(FILE_NAME, Context.MODE_PRIVATE);
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(ordenes);
        } catch (Exception e) { e.printStackTrace(); }
    }

    @SuppressWarnings("unchecked")
    private static List<Orden> leerOrdenesArchivo(Context context) {
        try (FileInputStream fis = context.openFileInput(FILE_NAME);
             ObjectInputStream ois = new ObjectInputStream(fis)) {
            return (List<Orden>) ois.readObject();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    private static int generarIdUnico(Random rnd, Set<Integer> usados) {
        int id; do { id = 10000 + rnd.nextInt(90000); } while (!usados.add(id)); return id;
    }

    private static String generarPlacaAleatoria(Random rand) {
        String L = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        return "" + L.charAt(rand.nextInt(26)) + L.charAt(rand.nextInt(26)) + L.charAt(rand.nextInt(26))
                + "-" + (1000 + rand.nextInt(9000));
    }
    private static Date generarFechaAleatoria(Random rand) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_MONTH, -rand.nextInt(30));
        return c.getTime();
    }

    private static List<Orden> repararOrdenesIncompletas(List<Orden> originales) {
        if (originales == null || originales.isEmpty()) return new ArrayList<>();
        boolean cambio = false;
        List<Orden> out = new ArrayList<>(originales.size());
        Random rnd = new Random();
        for (Orden o : originales) {
            String placa = o.getPlaca();
            Date fecha = o.getFecha();
            String desc  = o.getDescripcion();
            boolean faltaPlaca = (placa == null || placa.trim().isEmpty());
            boolean faltaFecha = (fecha == null);
            boolean faltaDesc  = (desc == null || desc.trim().isEmpty());
            if (faltaPlaca || faltaFecha || faltaDesc) {
                if (faltaPlaca) placa = generarPlacaAleatoria(rnd);
                if (faltaFecha) fecha = new Date();
                if (faltaDesc)  desc  = "Orden generada automática";
                out.add(new Orden(o.getId(), o.getNombreCliente(), desc, fecha, placa, o.getServicios()));
                cambio = true;
            } else out.add(o);
        }
        return cambio ? out : originales;
    }
}

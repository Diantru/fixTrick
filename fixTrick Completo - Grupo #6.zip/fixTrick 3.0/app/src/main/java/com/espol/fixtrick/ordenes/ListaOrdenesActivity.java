package com.espol.fixtrick.ordenes;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.espol.fixtrick.R;
import java.util.ArrayList;
import java.util.List;

public class ListaOrdenesActivity extends AppCompatActivity {

    private RecyclerView recyclerOrdenes;
    private Button btnCrearOrden;
    private final List<Orden> listaOrdenes = new ArrayList<>();
    private OrdenAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_ordenes);

        recyclerOrdenes = findViewById(R.id.recyclerOrdenes);
        btnCrearOrden   = findViewById(R.id.btnCrearOrden);
        recyclerOrdenes.setLayoutManager(new LinearLayoutManager(this));

        OrdenStorage.asegurarOrdenesPorDefecto(this);

        listaOrdenes.addAll(OrdenStorage.cargarOrdenes(this));

        adapter = new OrdenAdapter(listaOrdenes, orden -> {
            Intent i = new Intent(this, DetalleOrdenActivity.class);
            i.putExtra("orden", orden);
            startActivity(i);
        });
        recyclerOrdenes.setAdapter(adapter);

        btnCrearOrden.setOnClickListener(v ->
                startActivity(new Intent(this, CrearOrdenActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();

        OrdenStorage.asegurarOrdenesPorDefecto(this);

        listaOrdenes.clear();
        listaOrdenes.addAll(OrdenStorage.cargarOrdenes(this));
        adapter.notifyDataSetChanged();
    }
}

package com.espol.fixtrick.Proveedor.modeloProv;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class Proveedor implements Serializable {
    private int id;
    private String nombre;
    private int telefono;
    private String descripcion;
    public static final String nomArchivProv = "proveedor.ser";
    public static int ultimoIdProv = 0;

    public Proveedor(String nombre, int telefono, String descripcion) {
        this.id = ++ultimoIdProv;
        this.nombre = nombre;
        this.telefono = telefono;
        this.descripcion = descripcion;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public int getTelefono() {
        return telefono;
    }

    public String getDescripcion() {
        return descripcion;
    }

    @Override
    public String toString() {
        return id + " - " + nombre + " - " + telefono + " - " + descripcion;
    }

    public static ArrayList<Proveedor> obtenerProveedores() {
        ArrayList<Proveedor> lista = new ArrayList<>();

        lista.add(new Proveedor("Luis Gomez", 123456789, "Neumaticos"));
        lista.add(new Proveedor("Maria Rodriguez", 987654321, "Pintura"));
        lista.add(new Proveedor("Pedro Gomez", 123456789, "Motor"));
        return lista;
    }

    //leer los archivos donde se encuentran guardados los proveedores
    public static ArrayList<Proveedor> cargarProveedores(File directorio) throws Exception {
        ArrayList<Proveedor> lista = new ArrayList<>();
        File f = new File(directorio, nomArchivProv);
        //se escribe la lista serializada
        if (f.exists()) { //si no existe se crea la lista
            try (ObjectInputStream is = new ObjectInputStream(new FileInputStream(f))) {
                lista = (ArrayList<Proveedor>) is.readObject();
                Proveedor.ultimoIdProv = lista.size(); //establecer el ultimo id
            } catch (Exception e) {
                //quizas lance una excepción personalizada
                throw new Exception(e.getMessage());
            }
        }
        return lista;
    }

    /**
     *
     * @param directorio en android donde se guardará el archivo
     * @return true si se pudp crear el archivo o ya existe
     */

    public static boolean crearDatosIniciales(File directorio) throws Exception {
        ArrayList<Proveedor> lista = new ArrayList<>();
        boolean guardado = false;
        lista.add(new Proveedor("Luis Gomez", 123456789, "Neumaticos"));
        lista.add(new Proveedor("Maria Rodriguez", 987654321, "Pintura"));
        lista.add(new Proveedor("Pedro Gomez", 123456789, "Motor"));
        File f = new File(directorio, nomArchivProv);
        //se escribe la lista serializada
        if (!f.exists()) { //si no existe se crea la lista
            try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f))) {
                os.writeObject(lista);
                guardado = true;

            } catch(IOException e){
                //quizas lanza una excepcion personalizada
                throw new Exception(e.getMessage());
            }
        } else guardado = true; //si existe no se crea
        return guardado;
    }

    public static boolean guardarLista(File directorio, ArrayList<Proveedor> lista) throws Exception {
        boolean guardado = false;
        File f = new File(directorio, nomArchivProv);
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f))) {
            os.writeObject(lista);
            guardado = true;
        } catch (IOException e) {
            //quizas lanza una excepción
            throw new Exception(e.getMessage());
        }
        return guardado;
    }
}

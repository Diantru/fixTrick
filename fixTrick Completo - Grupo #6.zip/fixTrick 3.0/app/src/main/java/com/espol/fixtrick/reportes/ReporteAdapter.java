package com.espol.fixtrick.reportes;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.espol.fixtrick.R;
import java.util.List;
import java.util.Locale;

public class ReporteAdapter extends RecyclerView.Adapter<ReporteAdapter.ReporteViewHolder> {

    private List<ReporteItem> items;

    public ReporteAdapter(List<ReporteItem> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public ReporteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_reporte_detalle, parent, false);
        return new ReporteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReporteViewHolder holder, int position) {
        ReporteItem item = items.get(position);
        holder.tvConcepto.setText(item.getConcepto());
        holder.tvValor.setText(String.format(Locale.US, "$%.2f", item.getValor()));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ReporteViewHolder extends RecyclerView.ViewHolder {
        TextView tvConcepto, tvValor;
        public ReporteViewHolder(@NonNull View itemView) {
            super(itemView);
            tvConcepto = itemView.findViewById(R.id.tv_reporte_concepto);
            tvValor = itemView.findViewById(R.id.tv_reporte_valor);
        }
    }
}
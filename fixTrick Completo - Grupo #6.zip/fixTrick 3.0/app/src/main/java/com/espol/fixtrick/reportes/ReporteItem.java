package com.espol.fixtrick.reportes;

public class ReporteItem {
    private String concepto;
    private double valor;

    public ReporteItem(String concepto, double valor) {
        this.concepto = concepto;
        this.valor = valor;
    }

    public String getConcepto() { return concepto; }
    public double getValor() { return valor; }
}
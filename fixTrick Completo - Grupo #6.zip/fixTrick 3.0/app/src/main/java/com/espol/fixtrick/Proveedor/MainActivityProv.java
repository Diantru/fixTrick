package com.espol.fixtrick.Proveedor;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.espol.fixtrick.Proveedor.modeloProv.Proveedor;
import com.espol.fixtrick.R;

import java.util.ArrayList;

public class MainActivityProv extends AppCompatActivity {

    private RecyclerView recyclerView;
    private Proveedor_Adapter proveedorAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_prov);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //lenar lista de proveedores
        cargarDatos();

        Button btnAgregarProveedor = findViewById(R.id.agregarProveedor);
        btnAgregarProveedor.setOnClickListener(v -> {
            Intent intent = new Intent(this, AgregarProveedorActivity.class);
            startActivityForResult(intent, 1); //codigo 1 para identificar la respuesta
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void llenarLista(){
        recyclerView = findViewById(R.id.recyclerViewProv);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //Configurar el adaptador

        ArrayList<Proveedor> listaProveedores = new ArrayList<>();
        try{
            listaProveedores = Proveedor.cargarProveedores(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
            Log.d("MainActivityProv", "Lista de proveedores cargada correctamente");
        } catch(Exception e){
            listaProveedores = Proveedor.obtenerProveedores();
            Log.d("MainActivityProv", "Error al cargar la lista de proveedores: " + e.getMessage());
        }

        Log.d("MainActivityProv", "Lista de proveedores: " + listaProveedores.toString()); //muestra la lista en el log)

        proveedorAdapter = new Proveedor_Adapter(listaProveedores, this);
        recyclerView.setAdapter(proveedorAdapter);
    }

    private void cargarDatos(){
        boolean guardado = false;
        try{
            guardado = Proveedor.crearDatosIniciales(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
        } catch (Exception e){
            guardado = false;
            Log.d("MainActivityProv", "Error al crear los datos iniciales: " + e.getMessage());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null){
            String id = data.getStringExtra("id");
            String nombre = data.getStringExtra("nombre");
            int telefono = data.getIntExtra("telefono", 0);
            String descripcion = data.getStringExtra("descripcion");

            Proveedor nuevoProveedor = new Proveedor(nombre, telefono, descripcion);

            //Agregar a lista y guardar
            ArrayList<Proveedor> listaProveedores = proveedorAdapter.obtenerProveedores();
            listaProveedores.add(nuevoProveedor);
            proveedorAdapter.notifyItemInserted(listaProveedores.size() - 1);

            //Guardar en el archivo
            try{
                Proveedor.guardarLista(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), listaProveedores);
            } catch (Exception e){
                Toast.makeText(this, "Error al guardar la lista: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onResume(){
        super.onResume();
        llenarLista();
        Log.d("MainActivityProv", "En onResume()");
    }

    /*@Override
    public boolean onSupportNavigateUp(){
        finish(); //Cierra este activity y vuelve atrás
        return true;
    }*/
}
package com.espol.fixtrick.Cliente;

import android.content.Intent;
import android.os.Bundle;

import android.os.Environment;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.espol.fixtrick.R;
import com.espol.fixtrick.Cliente.modelo.Cliente;
import com.espol.fixtrick.Cliente.modelo.TipoCliente;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ClienteAdapter clienteAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        cargarDatos();

        Button btnAgregarCliente = findViewById(R.id.agregarCliente);
        btnAgregarCliente.setOnClickListener(v -> {
            // ==========================================================
            // ==                 CORRECCIÓN APLICADA AQUÍ             ==
            // ==========================================================
            Intent intent = new Intent(this, AgregarClienteActivity.class);
            startActivityForResult(intent, 1); //codigo 1 para identificar la respuesta
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void llenarLista(){
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        ArrayList<Cliente> listaClientes = new ArrayList<>();
        try{
            listaClientes = Cliente.cargarClientes(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
            Log.d("MainActivity", "Lista de clientes cargada correctamente");
        } catch (Exception e){
            listaClientes = Cliente.obtenerClientes();
            Log.d("MainActivity", "Error al cargar la lista de clientes: " + e.getMessage());
        }
        Log.d("MainActivity", "Lista de clientes: " + listaClientes.toString());
        clienteAdapter = new ClienteAdapter(listaClientes,this);
        recyclerView.setAdapter(clienteAdapter);
    }

    private void cargarDatos(){
        try{
            Cliente.crearDatosIniciales(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
        } catch (Exception e){
            Log.d("MainActivity", "Error al crear los datos iniciales: " + e.getMessage());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null){
            String nombre = data.getStringExtra("nombre");
            String direccion = data.getStringExtra("direccion");
            int telefono = data.getIntExtra("telefono", 0);
            String tipoClienteStr = data.getStringExtra("tipoCliente");
            TipoCliente tipoCliente = TipoCliente.valueOf(tipoClienteStr);

            Cliente nuevoCliente = new Cliente(nombre, direccion, telefono, tipoCliente);

            ArrayList<Cliente> listaClientes = clienteAdapter.obtenerClientes();
            listaClientes.add(nuevoCliente);
            clienteAdapter.notifyItemInserted(listaClientes.size() - 1);

            try{
                Cliente.guardarLista(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), listaClientes);
            } catch (Exception e) {
                Toast.makeText(this, "Error al guardar la lista: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onResume(){
        super.onResume();
        llenarLista();
        Log.d("MainActivity", "En onResume()");
    }
}
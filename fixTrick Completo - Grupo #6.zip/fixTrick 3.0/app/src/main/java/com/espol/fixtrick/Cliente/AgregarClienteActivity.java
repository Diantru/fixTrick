package com.espol.fixtrick.Cliente;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.espol.fixtrick.Cliente.modelo.Cliente;
import com.espol.fixtrick.R;
import com.espol.fixtrick.Cliente.modelo.TipoCliente;

public class AgregarClienteActivity extends AppCompatActivity {
    EditText etID, etNombre, etDireccion, etTelefono;
    Spinner spTipo;
    Button btnGuardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_cliente);

        etID = findViewById(R.id.etId);
        int siguienteId = Cliente.ultimoId + 1;;
        etID.setText(String.valueOf(siguienteId));
        etNombre = findViewById(R.id.etNombre);
        etDireccion = findViewById(R.id.etDireccion);
        etTelefono = findViewById(R.id.etTelefono);
        spTipo = findViewById(R.id.spTipoCliente);
        btnGuardar = findViewById(R.id.btnGuardar);

        ArrayAdapter<TipoCliente> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, TipoCliente.values());
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spTipo.setAdapter(adapter);

        btnGuardar.setOnClickListener(v -> {
            String nombre = etNombre.getText().toString().trim();
            String direccion = etDireccion.getText().toString().trim();
            String telStr = etTelefono.getText().toString().trim();

            if (nombre.isEmpty() || direccion.isEmpty() || telStr.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
                return;
            }

            int telefono;
            try {
                telefono = Integer.parseInt(telStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Teléfono inválido", Toast.LENGTH_SHORT).show();
                return;
            }

            TipoCliente tipo = (TipoCliente) spTipo.getSelectedItem();

            Intent resultado = new Intent();
            resultado.putExtra("nombre", nombre);
            resultado.putExtra("direccion", direccion);
            resultado.putExtra("telefono", telefono);
            resultado.putExtra("tipoCliente", tipo.name()); // enviamos el nombre del enum

            setResult(RESULT_OK, resultado);
            finish(); // cerrar esta pantalla
        });
    }
}

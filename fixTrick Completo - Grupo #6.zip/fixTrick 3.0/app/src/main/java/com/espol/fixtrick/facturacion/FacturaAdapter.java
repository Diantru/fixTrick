package com.espol.fixtrick.facturacion;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.espol.fixtrick.R;
import com.espol.fixtrick.ordenes.ServicioConCantidad;
import java.util.List;
import java.util.Locale;

public class FacturaAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TIPO_SERVICIO = 0;
    private static final int TIPO_CARGO_FIJO = 1;

    private List<ServicioConCantidad> servicios;
    private double cargoFijo;

    public FacturaAdapter(List<ServicioConCantidad> servicios, double cargoFijo) {
        this.servicios = servicios;
        this.cargoFijo = cargoFijo;
    }

    @Override
    public int getItemViewType(int position) {
        if (position < servicios.size()) {
            return TIPO_SERVICIO;
        }
        return TIPO_CARGO_FIJO;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        if (viewType == TIPO_SERVICIO) {
            View view = inflater.inflate(R.layout.item_reporte_detalle, parent, false);
            return new ServicioViewHolder(view);
        } else {
            View view = inflater.inflate(R.layout.item_reporte_detalle, parent, false);
            return new CargoFijoViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (getItemViewType(position) == TIPO_SERVICIO) {
            ServicioConCantidad item = servicios.get(position);
            ((ServicioViewHolder) holder).bind(item);
        } else {
            ((CargoFijoViewHolder) holder).bind(cargoFijo);
        }
    }

    @Override
    public int getItemCount() {
        return servicios.size() + 1; // +1 por el cargo fijo
    }

    static class ServicioViewHolder extends RecyclerView.ViewHolder {
        TextView tvConcepto, tvValor;
        public ServicioViewHolder(@NonNull View itemView) {
            super(itemView);
            tvConcepto = itemView.findViewById(R.id.tv_reporte_concepto);
            tvValor = itemView.findViewById(R.id.tv_reporte_valor);
        }
        void bind(ServicioConCantidad item) {
            tvConcepto.setText(item.getNombre() + " (x" + item.getCantidad() + ")");
            tvValor.setText(String.format(Locale.US, "$%.2f", item.getSubtotal()));
        }
    }

    static class CargoFijoViewHolder extends RecyclerView.ViewHolder {
        TextView tvConcepto, tvValor;
        public CargoFijoViewHolder(@NonNull View itemView) {
            super(itemView);
            tvConcepto = itemView.findViewById(R.id.tv_reporte_concepto);
            tvValor = itemView.findViewById(R.id.tv_reporte_valor);
        }
        void bind(double cargo) {
            tvConcepto.setText("Cargo Fijo Mensual");
            tvConcepto.setTypeface(null, android.graphics.Typeface.BOLD);
            tvValor.setText(String.format(Locale.US, "$%.2f", cargo));
        }
    }
}
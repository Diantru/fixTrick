package com.espol.fixtrick.Cliente.modelo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class Cliente implements Serializable {
    private int id;
    private String nombre;
    private String direccion;
    private int telefono;
    private TipoCliente tipoCliente;
    public static  final String nomArchiv = "cliente2.ser";
    public static int ultimoId = 0;

    public Cliente (String nombre, String direccion, int telefono, TipoCliente tipoCliente){
        this.id = ++ultimoId;
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.tipoCliente = tipoCliente;
    }

    public int getId(){
        return id;
    }

    public String getNombre(){
        return nombre;
    }

    public String getDireccion(){
        return direccion;
    }

    public int getTelefono(){
        return telefono;
    }

    public TipoCliente getTipoCliente(){
        return tipoCliente;
    }

    public String getSTipoCliente(){
        return tipoCliente.toString();
    }

    @Override
    public String toString(){
        return id + " - " + nombre + " - " + direccion + " - " + telefono + " - " + tipoCliente;
    }

    public static ArrayList<Cliente> obtenerClientes(){
        ArrayList<Cliente> lista = new ArrayList<>();

        lista.add(new Cliente( "Juan Perez", "Av. Siempre Viva 123", 123456789, TipoCliente.PERSONAL));
        lista.add(new Cliente( "Maria Rodriguez", "Calle Falsa 123", 987654321, TipoCliente.EMPRESARIAL));
        lista.add(new Cliente( "Pedro Gomez", "Av. Siempre Viva 456", 123456789, TipoCliente.PERSONAL));
        return lista;
    }

    //leer los archivos donde se encuentran guardados los clientes
    public static ArrayList<Cliente> cargarClientes(File directorio) throws Exception{
        ArrayList<Cliente> lista = new ArrayList<>();
        File f = new File(directorio, nomArchiv);
        //se escribe la lista serializada
        if (f.exists()) { //si no existe se crea la lista
            try (ObjectInputStream is = new ObjectInputStream(new FileInputStream(f))){
                lista = (ArrayList<Cliente>) is.readObject();
                Cliente.ultimoId = lista.size(); //establecer el ultimo id
            } catch (Exception e) {
                //quizas lance una excepción personalizada
                throw new Exception(e.getMessage());
            }
        }
        return lista;
    }

    /**
     *
     * @param directorio en android donde se guardará el archivo
     * @return true si se pudp crear el archivo o ya existe
     */

    public static boolean crearDatosIniciales(File directorio) throws Exception{
        ArrayList<Cliente> lista = new ArrayList<>();
        boolean guardado = false;
        lista.add(new Cliente( "Juan Perez", "Av. Siempre Viva 123", 123456789, TipoCliente.PERSONAL));
        lista.add(new Cliente( "Maria Rodriguez", "Calle Falsa 123", 987654321, TipoCliente.EMPRESARIAL));
        lista.add(new Cliente( "Pedro Gomez", "Av. Siempre Viva 456", 123456789, TipoCliente.PERSONAL));
        File f = new File(directorio, nomArchiv);
        //se escribe la lista serializada
        if (!f.exists()) { //si no existe se crea la lista
            try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f))) {
                os.writeObject(lista);
                guardado = true;

            } catch(IOException e){
                //quizas lanza una excepcion personalizada
                throw new Exception(e.getMessage());
            }
        }else guardado = true; //si existe no se crea
        return guardado;
    }

    public static boolean guardarLista(File directorio, ArrayList<Cliente> lista) throws Exception{
        boolean guardado = false;
        File f = new File(directorio, nomArchiv);
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f))) {
            os.writeObject(lista);
            guardado = true;
        } catch (IOException e) {
            //quizas lanza una excepción
            throw new Exception(e.getMessage());
        }
        return guardado;
    }
}

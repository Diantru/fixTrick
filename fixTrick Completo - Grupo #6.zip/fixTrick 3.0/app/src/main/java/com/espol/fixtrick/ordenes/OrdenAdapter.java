package com.espol.fixtrick.ordenes;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.espol.fixtrick.R;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class OrdenAdapter extends RecyclerView.Adapter<OrdenAdapter.OrdenViewHolder> {

    public interface OnItemClickListener { void onItemClick(Orden orden); }

    private List<Orden> listaOrdenes;
    private OnItemClickListener listener;

    public OrdenAdapter(List<Orden> listaOrdenes, OnItemClickListener listener) {
        this.listaOrdenes = listaOrdenes;
        this.listener = listener;
    }

    public OrdenAdapter(List<Orden> listaOrdenes) {
        this.listaOrdenes = listaOrdenes;
        this.listener = null;
    }

    @NonNull
    @Override
    public OrdenViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_orden, parent, false);
        return new OrdenViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull OrdenViewHolder holder, int position) {
        Orden o = listaOrdenes.get(position);
        holder.tvCliente.setText("Cliente: " + o.getNombreCliente());
        holder.tvFecha.setText("Fecha: " + new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(o.getFecha()));
        holder.tvPlaca.setText("Placa: " + o.getPlaca());
        holder.tvTotal.setText("Total a pagar: $" + String.format(Locale.getDefault(), "%.2f", o.getTotal()));

        holder.btnMasDetalle.setOnClickListener(v -> {
            if (listener != null) listener.onItemClick(o);
        });
    }

    @Override
    public int getItemCount() { return listaOrdenes.size(); }

    static class OrdenViewHolder extends RecyclerView.ViewHolder {
        TextView tvCliente, tvFecha, tvPlaca, tvTotal;
        Button btnMasDetalle;

        public OrdenViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCliente = itemView.findViewById(R.id.tvCliente);
            tvFecha = itemView.findViewById(R.id.tvFecha);
            tvPlaca = itemView.findViewById(R.id.tvPlaca);
            tvTotal = itemView.findViewById(R.id.tvTotal);
            btnMasDetalle = itemView.findViewById(R.id.btnMasDetalle);
        }
    }
}

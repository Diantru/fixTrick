package com.espol.fixtrick.ordenes;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.espol.fixtrick.R;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class DetalleOrdenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_orden);

        Orden orden = (Orden) getIntent().getSerializableExtra("orden");
        TextView tvInfo = findViewById(R.id.tvInfo);
        LinearLayout layoutServicios = findViewById(R.id.layoutServiciosDetalle);

        if (orden != null) {
            String info = "Cliente: " + orden.getNombreCliente() + "\n" +
                    "Descripción: " + orden.getDescripcion() + "\n" +
                    "Fecha: " + new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(orden.getFecha()) + "\n" +
                    "Placa: " + orden.getPlaca() + "\n" +
                    "Total: $" + String.format(Locale.getDefault(), "%.2f", orden.getTotal());
            tvInfo.setText(info);

            layoutServicios.removeAllViews();
            for (ServicioConCantidad s : orden.getServicios()) {
                TextView tv = new TextView(this);
                tv.setText(s.getNombre() + " - Cantidad: " + s.getCantidad() + " - Subtotal: $" +
                        String.format(Locale.getDefault(), "%.2f", s.getSubtotal()));
                tv.setPadding(6,6,6,6);
                layoutServicios.addView(tv);
            }
        }
    }
}

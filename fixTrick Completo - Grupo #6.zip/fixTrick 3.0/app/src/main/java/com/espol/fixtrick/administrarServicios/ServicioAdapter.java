package com.espol.fixtrick.administrarServicios;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import com.espol.fixtrick.R;

public class ServicioAdapter extends RecyclerView.Adapter<ServicioAdapter.ViewHolder> {
    private List<Servicio> servicios;
    private OnEditarClickListener listener;

    public interface OnEditarClickListener {
        void onEditarClick(int position);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvCodigo, tvNombre, tvPrecio;
        Button btnEditar;

        public ViewHolder(View itemView) {
            super(itemView);
            tvCodigo = itemView.findViewById(R.id.tvCodigo);
            tvNombre = itemView.findViewById(R.id.tvNombre);
            tvPrecio = itemView.findViewById(R.id.tvPrecio);
            btnEditar = itemView.findViewById(R.id.btnEditar);
        }
    }

    public ServicioAdapter(List<Servicio> servicios, OnEditarClickListener listener) {
        this.servicios = servicios;
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_servicio, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Servicio servicio = servicios.get(position);
        holder.tvCodigo.setText("Código: " + servicio.getCodigo());
        holder.tvNombre.setText("Nombre: " + servicio.getNombre());
        holder.tvPrecio.setText("Precio: $" + servicio.getPrecio());
        holder.btnEditar.setOnClickListener(v -> listener.onEditarClick(position));
    }

    @Override
    public int getItemCount() {
        return servicios.size();
    }
}
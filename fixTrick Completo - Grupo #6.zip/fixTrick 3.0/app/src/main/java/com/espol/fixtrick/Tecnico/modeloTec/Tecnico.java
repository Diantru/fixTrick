package com.espol.fixtrick.Tecnico.modeloTec;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class Tecnico implements Serializable {
    private int id;
    private String nombre;
    private int telefono;
    private String especialidad;
    public static final String nomArchivTec = "tecnico.ser";
    public static int ultimoIdTec = 0;

    public Tecnico(String nombre, int telefono, String especialidad){
        this.id = ++ultimoIdTec;
        this.nombre = nombre;
        this.telefono = telefono;
        this.especialidad = especialidad;
    }

    public int getId(){
        return id;
    }

    public String getNombre(){
        return nombre;
    }

    public int getTelefono(){
        return telefono;
    }

    public String getEspecialidad(){
        return especialidad;
    }

    @Override
    public String toString(){
        return id + " - " + nombre + " - " + telefono + " - " + especialidad;
    }

    public static ArrayList<Tecnico> obtenerTecnicos(){
        ArrayList<Tecnico> lista = new ArrayList<>();

        lista.add(new Tecnico("Robert Linzai", 123456789, "Motor"));
        lista.add(new Tecnico("Maria Rodriguez", 987654321, "Pintura"));
        lista.add(new Tecnico("Pedro Gomez", 123456789, "Frenos"));
        return lista;
    }

    //leer los archivos donde se encuentran guardados los tecnicos
    public static ArrayList<Tecnico> cargarTecnicos(File directorio) throws Exception {
        ArrayList<Tecnico> lista = new ArrayList<>();
        File f = new File(directorio, nomArchivTec);
        //se escribe la lista serializada
        if (f.exists()) { //si no existe se crea la lista
            try (ObjectInputStream is = new ObjectInputStream(new FileInputStream(f))){
                lista = (ArrayList<Tecnico>) is.readObject();
                Tecnico.ultimoIdTec = lista.size(); //establecer el ultimo id
            } catch (Exception e){
                //quizas lance una excepción personalizada
                throw new Exception(e.getMessage());
            }
        }
        return lista;
    }

    /**
     *
     * @param directorio en android donde se guardará el archivo
     * @return true si se pudp crear el archivo o ya existe
     */

    public static boolean crearDatosIniciales(File directorio) throws Exception{
        ArrayList<Tecnico> lista = new ArrayList<>();
        boolean guardado = false;
        lista.add(new Tecnico("Robert Linzai", 123456789, "Motor"));
        lista.add(new Tecnico("Maria Rodriguez", 987654321, "Pintura"));
        lista.add(new Tecnico("Pedro Gomez", 123456789, "Frenos"));
        File f = new File(directorio, nomArchivTec);
        //se escribe la lista seralizada
        if (! f.exists()){ //si no existe se crea la lista
            try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f))){
                os.writeObject(lista);
                guardado = true;

            } catch(IOException e){
                //quizas lanza una excepcion personalizada
                throw new Exception(e.getMessage());
            }
        } else guardado = true; //si existe no se crea
        return guardado;
    }

    public static boolean guardarLista(File directorio, ArrayList<Tecnico> lista) throws Exception{
        boolean guardado = false;
        File f = new File(directorio, nomArchivTec);
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f))){
            os.writeObject(lista);
            guardado = true;
        } catch (IOException e){
            //quizas lanza una excepcion personalizada
            throw new Exception(e.getMessage());
        }
        return guardado;
    }
}

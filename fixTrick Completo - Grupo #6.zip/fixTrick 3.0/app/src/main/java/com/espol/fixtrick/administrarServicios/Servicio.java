package com.espol.fixtrick.administrarServicios;

import java.io.*;
import java.util.ArrayList;

public class Servicio implements Serializable {
    private String codigo;
    private String nombre;
    private double precio;

    public static final String FILE_NAME = "servicios2.ser";

    public Servicio(String codigo, String nombre, double precio) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
    }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public static ArrayList<Servicio> obtenerServicios() {
        ArrayList<Servicio> lista = new ArrayList<>();
        lista.add(new Servicio("ACEITE-1", "Cambio de Aceite", 50.0));
        lista.add(new Servicio("FRENO-99", "Reparación de Frenos", 120.0));
        lista.add(new Servicio("DIAG-10", "Diagnóstico General", 75.0));
        return lista;
    }

    public static boolean crearDatosIniciales(File directorio) throws Exception {
        if (directorio == null) return false;
        File f = new File(directorio, FILE_NAME);
        if (f.exists()) return true;
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f))) {
            oos.writeObject(obtenerServicios());
            return true;
        } catch (IOException e) { throw new Exception(e.getMessage()); }
    }

    @SuppressWarnings("unchecked")
    public static ArrayList<Servicio> cargarServicios(File directorio) throws Exception {
        ArrayList<Servicio> lista = new ArrayList<>();
        if (directorio == null) return lista;
        File f = new File(directorio, FILE_NAME);
        if (!f.exists()) return lista;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))) {
            return (ArrayList<Servicio>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) { throw new Exception(e.getMessage()); }
    }

    public static boolean guardarLista(File directorio, ArrayList<Servicio> lista) throws Exception {
        if (directorio == null) return false;
        File f = new File(directorio, FILE_NAME);
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f))) {
            oos.writeObject(lista);
            return true;
        } catch (IOException e) { throw new Exception(e.getMessage()); }
    }
}

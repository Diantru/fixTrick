package com.espol.fixtrick.ordenes;

import com.espol.fixtrick.administrarServicios.Servicio;
import java.io.Serializable;

public class ServicioConCantidad implements Serializable {
    private Servicio servicio;
    private int cantidad;
    private double subtotal;

    public ServicioConCantidad(Servicio servicio, int cantidad) {
        this.servicio = servicio;
        this.cantidad = cantidad;
        this.subtotal = servicio.getPrecio() * cantidad;
    }

    public Servicio getServicio() {
        return servicio;
    }
    public int getCantidad() {
        return cantidad;
    }
    public double getSubtotal() {
        return subtotal;
    }
    public String getNombre() {
        return servicio.getNombre();
    }
}

package com.espol.fixtrick.administrarServicios;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.espol.fixtrick.R;

import java.util.ArrayList;

public class ServiciosActivity extends AppCompatActivity {
    private RecyclerView rvServicios;
    private ArrayList<Servicio> servicios;
    private ServicioAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_servicios);

        try {
            Servicio.crearDatosIniciales(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
            servicios = Servicio.cargarServicios(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
        } catch (Exception e) {
            servicios = new ArrayList<>();
            Toast.makeText(this, "Error cargando servicios: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        rvServicios = findViewById(R.id.rvServicios);
        rvServicios.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ServicioAdapter(servicios, this::editarServicio);
        rvServicios.setAdapter(adapter);

        findViewById(R.id.btnAgregar).setOnClickListener(v -> mostrarDialogoAgregar());
    }

    private void mostrarDialogoAgregar() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_servicio, null);
        EditText etCodigo = view.findViewById(R.id.etCodigo);
        EditText etNombre = view.findViewById(R.id.etNombre);
        EditText etPrecio = view.findViewById(R.id.etPrecio);

        builder.setView(view)
                .setTitle("Agregar Servicio")
                .setPositiveButton("Guardar", (dialog, which) -> {
                    String codigo = etCodigo.getText().toString().trim();
                    String nombre = etNombre.getText().toString().trim();
                    String precioStr = etPrecio.getText().toString().trim();

                    if (codigo.isEmpty() || nombre.isEmpty() || precioStr.isEmpty()) {
                        Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (codigoExistente(codigo)) {
                        Toast.makeText(this, "El código ya existe", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    try {
                        double precio = Double.parseDouble(precioStr);
                        if (precio <= 0) {
                            Toast.makeText(this, "El precio debe ser mayor a 0", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        servicios.add(new Servicio(codigo, nombre, precio));
                        adapter.notifyItemInserted(servicios.size() - 1);
                        Servicio.guardarLista(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), servicios);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Ingrese un precio válido", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(this, "Error guardando: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private boolean codigoExistente(String codigo) {
        for (Servicio s : servicios) if (s.getCodigo().equalsIgnoreCase(codigo)) return true;
        return false;
    }

    private void editarServicio(int position) {
        Servicio servicio = servicios.get(position);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_servicio, null);
        EditText etCodigo = view.findViewById(R.id.etCodigo);
        EditText etNombre = view.findViewById(R.id.etNombre);
        EditText etPrecio = view.findViewById(R.id.etPrecio);

        etCodigo.setText(servicio.getCodigo());
        etNombre.setText(servicio.getNombre());
        etPrecio.setText(String.valueOf(servicio.getPrecio()));
        etCodigo.setEnabled(false);
        etNombre.setEnabled(false);

        builder.setView(view)
                .setTitle("Editar Servicio")
                .setPositiveButton("Guardar", (dialog, which) -> {
                    String precioStr = etPrecio.getText().toString().trim();
                    if (precioStr.isEmpty()) {
                        Toast.makeText(this, "El precio no puede estar vacío", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    try {
                        double nuevoPrecio = Double.parseDouble(precioStr);
                        if (nuevoPrecio <= 0) {
                            Toast.makeText(this, "El precio debe ser mayor a 0", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        servicio.setPrecio(nuevoPrecio);
                        adapter.notifyItemChanged(position);
                        Servicio.guardarLista(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), servicios);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Ingrese un precio válido", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(this, "Error guardando: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }
}

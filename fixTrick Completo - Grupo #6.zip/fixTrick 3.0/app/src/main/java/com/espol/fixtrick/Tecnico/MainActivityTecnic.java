package com.espol.fixtrick.Tecnico;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.espol.fixtrick.R;
import com.espol.fixtrick.Tecnico.modeloTec.Tecnico;

import java.util.ArrayList;

public class MainActivityTecnic extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TecnicoAdapter tecnicoAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_tecnic);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //llenar lista de tecnicos
        cargarDatos();

        Button btnAgregarTecnico = findViewById(R.id.agregarTecnico);
        btnAgregarTecnico.setOnClickListener(v -> {
           Intent intent = new Intent(this, AgregarTecnico.class);
           startActivityForResult(intent, 1); //codigo 1 para identificar la respuesta
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void llenarLista(){
        recyclerView = findViewById(R.id.recyclerViewTec);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        ArrayList<Tecnico> listaTecnicos = new ArrayList<>();
        try{
            listaTecnicos = Tecnico.cargarTecnicos(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
            Log.d("MainActivityTecnic", "Lista de técnicos cargada correctamente");
        } catch(Exception e){
            listaTecnicos = Tecnico.obtenerTecnicos();
            Log.d("MainActivityTecnic", "Error al cargar la lista de técnicos: " + e.getMessage());
        }

        Log.d("MainActivityTecnic", "Lista de técnicos: " + listaTecnicos.toString()); //muestra la lista en el log

        tecnicoAdapter = new TecnicoAdapter(listaTecnicos, this);
        recyclerView.setAdapter(tecnicoAdapter);
    }

    private void cargarDatos(){
        boolean guardado = false;
        try{
            guardado = Tecnico.crearDatosIniciales(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
        } catch(Exception e){
            guardado = false;
            Log.d("MainActivityTecnic", "Error al crear los datos iniciales: " + e.getMessage());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null){
            String id = data.getStringExtra("id");
            String nombre = data.getStringExtra("nombre");
            int telefono = data.getIntExtra("telefono", 0);
            String especialidad = data.getStringExtra("especialidad");

            Tecnico nuevoTecnico = new Tecnico(nombre, telefono, especialidad);

            //Agregar a lista y guardar
            ArrayList<Tecnico> listaTecnicos = tecnicoAdapter.obtenerTecnicos();
            listaTecnicos.add(nuevoTecnico);
            tecnicoAdapter.notifyItemInserted(listaTecnicos.size() - 1);

            //Guardar en el archivo
            try{
                Tecnico.guardarLista(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), listaTecnicos);
            } catch(Exception e){
                Toast.makeText(this, "Error al guardar la lista: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onResume(){
        super.onResume();
        llenarLista();
        Log.d("MainActivityTecnic", "En onResume()");
    }

    /*@Override
    public boolean onSupportNavigateUp(){
        finish(); //Cierra este activity y vuelve atrás
        return true;
    }*/
}
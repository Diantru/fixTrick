package com.espol.fixtrick.reportes;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.espol.fixtrick.R;
import com.espol.fixtrick.negocio.DatosManager;
import com.espol.fixtrick.negocio.OrdenParcheada;
import com.espol.fixtrick.ordenes.ServicioConCantidad;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ReporteResultadoActivity extends AppCompatActivity {

    TextView tvTituloReporte, tvTotalGeneral;
    RecyclerView recyclerReporte;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reporte_resultado);

        tvTituloReporte = findViewById(R.id.tv_titulo_reporte);
        tvTotalGeneral = findViewById(R.id.tv_total_general_reporte);
        recyclerReporte = findViewById(R.id.recycler_reporte);
        recyclerReporte.setLayoutManager(new LinearLayoutManager(this));

        // Inicializar datos si aún no se ha hecho
        DatosManager.inicializar(this);

        // Obtener datos del Intent
        String tipoReporte = getIntent().getStringExtra("TIPO_REPORTE");
        int anio = getIntent().getIntExtra("ANIO", 0);
        int mes = getIntent().getIntExtra("MES", 0) - 1; // Meses de Calendar son 0-11

        generarReporte(tipoReporte, anio, mes);
    }

    private void generarReporte(String tipo, int anio, int mes) {
        List<OrdenParcheada> ordenesFiltradas = new ArrayList<>();
        for (OrdenParcheada op : DatosManager.getOrdenesParcheadas()) {
            Calendar cal = Calendar.getInstance();
            cal.setTime(op.getFecha());
            if (cal.get(Calendar.YEAR) == anio && cal.get(Calendar.MONTH) == mes) {
                ordenesFiltradas.add(op);
            }
        }

        double totalGeneral = ordenesFiltradas.stream().mapToDouble(OrdenParcheada::getTotal).sum();
        tvTotalGeneral.setText(String.format("Total General del Mes: $%.2f", totalGeneral));

        List<ReporteItem> resultados = new ArrayList<>();
        if ("SERVICIO".equals(tipo)) {
            tvTituloReporte.setText("Reporte de Ingresos por Servicio");
            Map<String, Double> ingresosPorServicio = new HashMap<>();
            for (OrdenParcheada op : ordenesFiltradas) {
                for (ServicioConCantidad sc : op.getServicios()) {
                    ingresosPorServicio.merge(sc.getNombre(), sc.getSubtotal(), Double::sum);
                }
            }
            resultados = ingresosPorServicio.entrySet().stream()
                    .map(e -> new ReporteItem(e.getKey(), e.getValue()))
                    .collect(Collectors.toList());

        } else if ("TECNICO".equals(tipo)) {
            tvTituloReporte.setText("Reporte de Atenciones por Técnico");
            Map<String, Double> ingresosPorTecnico = new HashMap<>();
            for (OrdenParcheada op : ordenesFiltradas) {
                if (op.getTecnico() != null) {
                    ingresosPorTecnico.merge(op.getTecnico().getNombre(), op.getTotal(), Double::sum);
                }
            }
            resultados = ingresosPorTecnico.entrySet().stream()
                    .map(e -> new ReporteItem(e.getKey(), e.getValue()))
                    .collect(Collectors.toList());
        }

        ReporteAdapter adapter = new ReporteAdapter(resultados);
        recyclerReporte.setAdapter(adapter);
    }
}
package com.espol.fixtrick.Tecnico;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.espol.fixtrick.R;
import com.espol.fixtrick.Tecnico.modeloTec.Tecnico;

import java.util.ArrayList;

public class TecnicoAdapter extends RecyclerView.Adapter<TecnicoAdapter.TecnicoViewHolder>{

    private ArrayList<Tecnico> tecnicos;
    private Context context;

    public TecnicoAdapter(ArrayList<Tecnico> tecnicos, Context context){
        this.tecnicos = tecnicos;
        this.context = context;
    }

    @Override
    public TecnicoViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_tecnico, parent, false);
        return new TecnicoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(TecnicoViewHolder holder, int position){
        Tecnico tecnico = tecnicos.get(position);
        holder.idTextView.setText("ID: " + tecnico.getId());
        holder.nombreTextView.setText("Nombre: " + tecnico.getNombre());
        holder.telefonoTextView.setText(String.valueOf("Teléfono: " + tecnico.getTelefono()));
        holder.especialidadTextView.setText("Especialidad: " + tecnico.getEspecialidad());
    }

    @Override
    public int getItemCount(){
        return tecnicos.size();
    }

    public ArrayList<Tecnico> obtenerTecnicos(){
        return tecnicos;
    }

    public static class TecnicoViewHolder extends RecyclerView.ViewHolder{
        TextView idTextView;
        TextView nombreTextView;
        TextView telefonoTextView;
        TextView especialidadTextView;

        public TecnicoViewHolder(View itemView){
            super(itemView);
            idTextView = itemView.findViewById(R.id.tvIdTec);
            nombreTextView = itemView.findViewById(R.id.tvNombreTec);
            telefonoTextView = itemView.findViewById(R.id.tvTelefonoTec);
            especialidadTextView = itemView.findViewById(R.id.tvEspecialidadTec);

        }
    }
}

package com.espol.fixtrick.Cliente.modelo;

import androidx.annotation.NonNull;

public enum TipoCliente {
    PERSONAL,
    EMPRESARIAL;

    @Override
    public String toString(){
        switch (this){
            case PERSONAL:
                return "PERSONAL";
            case EMPRESARIAL:
                return "EMPRESARIAL";
            default:
                return "";
        }
    }
}


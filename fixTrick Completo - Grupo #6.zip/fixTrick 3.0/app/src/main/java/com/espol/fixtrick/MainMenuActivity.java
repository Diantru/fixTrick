package com.espol.fixtrick;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import com.espol.fixtrick.Cliente.MainActivity;
import com.espol.fixtrick.Proveedor.MainActivityProv;
import com.espol.fixtrick.Tecnico.MainActivityTecnic;
import com.espol.fixtrick.administrarServicios.ServiciosActivity;
import com.espol.fixtrick.facturacion.FacturacionActivity; // <-- Importar tu Activity
import com.espol.fixtrick.ordenes.OrdenesActivity;
import com.espol.fixtrick.reportes.ReporteFiltroActivity; // <-- Importar tu Activity

public class MainMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        // --- Botones de tus compañeros ---
        Button btnClientes = findViewById(R.id.btnClientes);
        Button btnProveedores = findViewById(R.id.btnProveedores);
        Button btnTecnicos = findViewById(R.id.btnTecnicos);
        Button btnServicios = findViewById(R.id.btnServicios);
        Button btnGenerarOrden = findViewById(R.id.btnGenerarOrden);

        btnClientes.setOnClickListener(v -> startActivity(new Intent(this, MainActivity.class)));
        btnProveedores.setOnClickListener(v -> startActivity(new Intent(this, MainActivityProv.class)));
        btnTecnicos.setOnClickListener(v -> startActivity(new Intent(this, MainActivityTecnic.class)));
        btnServicios.setOnClickListener(v -> startActivity(new Intent(this, ServiciosActivity.class)));
        btnGenerarOrden.setOnClickListener(v -> startActivity(new Intent(this, OrdenesActivity.class)));

        // --- Tus nuevos botones ---
        Button btnGenerarFactura = findViewById(R.id.btnGenerarFactura);
        Button btnReportes = findViewById(R.id.btnReportes);

        btnGenerarFactura.setOnClickListener(v -> startActivity(new Intent(this, FacturacionActivity.class)));
        btnReportes.setOnClickListener(v -> startActivity(new Intent(this, ReporteFiltroActivity.class)));
    }
}
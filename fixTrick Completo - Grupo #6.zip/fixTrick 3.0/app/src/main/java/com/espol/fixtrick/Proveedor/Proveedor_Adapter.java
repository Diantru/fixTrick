package com.espol.fixtrick.Proveedor;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.espol.fixtrick.Proveedor.modeloProv.Proveedor;
import com.espol.fixtrick.R;

import java.util.ArrayList;

public class Proveedor_Adapter extends RecyclerView.Adapter<Proveedor_Adapter.ProveedorViewHolder>{

    private ArrayList<Proveedor> proveedores;
    private Context context;

    public Proveedor_Adapter(ArrayList<Proveedor> proveedores, Context context){
        this.proveedores = proveedores;
        this.context = context;
    }

    @Override
    public ProveedorViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_proveedor, parent, false);
        return new ProveedorViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ProveedorViewHolder holder, int position){
        Proveedor proveedor = proveedores.get(position);
        holder.idTextView.setText("ID: " + proveedor.getId());
        holder.nombreTextView.setText("Nombre: " + proveedor.getNombre());
        holder.telefonoTextView.setText(String.valueOf("Teléfono: " + proveedor.getTelefono()));
        holder.descripcionTextView.setText("Descripción: " + proveedor.getDescripcion());
    }

    @Override
    public int getItemCount(){
        return proveedores.size();
    }

    public ArrayList<Proveedor> obtenerProveedores(){
        return proveedores;
    }

    public static class ProveedorViewHolder extends RecyclerView.ViewHolder {
        TextView idTextView;
        TextView nombreTextView;
        TextView telefonoTextView;
        TextView descripcionTextView;

        public ProveedorViewHolder(View itemView) {
            super(itemView);
            idTextView = itemView.findViewById(R.id.tvIdProv);
            nombreTextView = itemView.findViewById(R.id.tvNombreProv);
            telefonoTextView = itemView.findViewById(R.id.tvTelefonoProv);
            descripcionTextView = itemView.findViewById(R.id.tvDescripcionProv);
        }
    }
}

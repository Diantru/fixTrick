package com.espol.fixtrick.Cliente;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.espol.fixtrick.R;
import com.espol.fixtrick.Cliente.modelo.Cliente;

import java.util.ArrayList;

public class ClienteAdapter extends RecyclerView.Adapter<ClienteAdapter.ClienteViewHolder>{

    private ArrayList<Cliente> clientes;
    private Context context;
    public ClienteAdapter(ArrayList<Cliente> clientes, Context context){
        this.clientes = clientes;
        this.context = context;
    }

    @Override
    public ClienteViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cliente, parent, false);
        return new ClienteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ClienteViewHolder holder, int position){
        Cliente cliente = clientes.get(position);
        holder.idTextView.setText("ID: " + cliente.getId());
        holder.nombreTextView.setText("Nombre: " + cliente.getNombre());
        holder.direccionTextView.setText("Direccion: " + cliente.getDireccion());
        holder.telefonoTextView.setText(String.valueOf("Teléfono: " + cliente.getTelefono()));
        holder.tipoClienteTextView.setText("Tipo de Cliente: " + cliente.getSTipoCliente());
    }

    @Override
    public int getItemCount(){
        return clientes.size();
    }

    public ArrayList<Cliente> obtenerClientes(){
        return clientes;
    }

    public static class ClienteViewHolder extends RecyclerView.ViewHolder{
        TextView idTextView;
        TextView nombreTextView;
        TextView direccionTextView;
        TextView telefonoTextView;
        TextView tipoClienteTextView;

        public ClienteViewHolder(View itemView){
            super(itemView);
            idTextView = itemView.findViewById(R.id.tvId);
            nombreTextView = itemView.findViewById(R.id.tvNombre);
            direccionTextView = itemView.findViewById(R.id.tvDireccion);
            telefonoTextView = itemView.findViewById(R.id.tvTelefono);
            tipoClienteTextView = itemView.findViewById(R.id.tvTipoCliente);
        }
    }
}

package com.espol.fixtrick.facturacion;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.espol.fixtrick.Cliente.modelo.Cliente;
import com.espol.fixtrick.R;
import com.espol.fixtrick.negocio.DatosManager;
import com.espol.fixtrick.negocio.OrdenParcheada;
import com.espol.fixtrick.ordenes.ServicioConCantidad;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.stream.Collectors;

public class FacturacionActivity extends AppCompatActivity {

    Spinner spinnerClientes;
    EditText etAnio, etMes;
    Button btnGenerarFactura;
    TextView tvTotalFactura;
    RecyclerView recyclerDetalleFactura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facturacion);

        spinnerClientes = findViewById(R.id.spinner_clientes_empresariales);
        etAnio = findViewById(R.id.et_anio_factura);
        etMes = findViewById(R.id.et_mes_factura);
        btnGenerarFactura = findViewById(R.id.btn_generar_factura);
        tvTotalFactura = findViewById(R.id.tv_total_factura);
        recyclerDetalleFactura = findViewById(R.id.recycler_detalle_factura);
        recyclerDetalleFactura.setLayoutManager(new LinearLayoutManager(this));

        // Inicializar los datos parcheados
        DatosManager.inicializar(this);

        configurarSpinner();

        btnGenerarFactura.setOnClickListener(v -> generarFactura());
    }

    private void configurarSpinner() {
        List<Cliente> clientesEmpresariales = DatosManager.getClientesEmpresariales();
        List<String> nombresClientes = clientesEmpresariales.stream()
                .map(Cliente::getNombre)
                .collect(Collectors.toList());

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, nombresClientes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerClientes.setAdapter(adapter);
    }

    private void generarFactura() {
        String anioStr = etAnio.getText().toString();
        String mesStr = etMes.getText().toString();

        if (spinnerClientes.getSelectedItem() == null) {
            Toast.makeText(this, "No hay clientes empresariales para facturar.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (anioStr.isEmpty() || mesStr.isEmpty()) {
            Toast.makeText(this, "Por favor ingrese año y mes.", Toast.LENGTH_SHORT).show();
            return;
        }

        int anio = Integer.parseInt(anioStr);
        int mes = Integer.parseInt(mesStr) - 1; // Calendar usa meses de 0 a 11

        String nombreClienteSeleccionado = (String) spinnerClientes.getSelectedItem();
        List<Cliente> clientesEmpresariales = DatosManager.getClientesEmpresariales();
        Cliente clienteSeleccionado = clientesEmpresariales.stream()
                .filter(c -> c.getNombre().equals(nombreClienteSeleccionado))
                .findFirst().orElse(null);

        if (clienteSeleccionado == null) return;

        List<OrdenParcheada> ordenesCliente = new ArrayList<>();
        double subtotalServicios = 0;

        List<ServicioConCantidad> todosLosServicios = new ArrayList<>();

        for (OrdenParcheada op : DatosManager.getOrdenesParcheadas()) {
            if (op.getCliente() != null && op.getCliente().getId() == clienteSeleccionado.getId()) {
                Calendar cal = Calendar.getInstance();
                cal.setTime(op.getFecha());
                if (cal.get(Calendar.YEAR) == anio && cal.get(Calendar.MONTH) == mes) {
                    subtotalServicios += op.getTotal();
                    todosLosServicios.addAll(op.getServicios());
                }
            }
        }

        double cargoFijo = 50.0;
        double totalFinal = subtotalServicios + cargoFijo;

        FacturaAdapter adapter = new FacturaAdapter(todosLosServicios, cargoFijo);
        recyclerDetalleFactura.setAdapter(adapter);

        tvTotalFactura.setText(String.format("TOTAL A PAGAR: $%.2f", totalFinal));
        tvTotalFactura.setVisibility(View.VISIBLE);
    }
}
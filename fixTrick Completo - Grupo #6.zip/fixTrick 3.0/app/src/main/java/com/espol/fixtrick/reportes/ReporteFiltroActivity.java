package com.espol.fixtrick.reportes;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.espol.fixtrick.R;

public class ReporteFiltroActivity extends AppCompatActivity {

    EditText etAnio, etMes;
    Button btnReporteServicio, btnReporteTecnico;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reporte_filtro);

        etAnio = findViewById(R.id.et_anio_reporte);
        etMes = findViewById(R.id.et_mes_reporte);
        btnReporteServicio = findViewById(R.id.btn_reporte_servicio);
        btnReporteTecnico = findViewById(R.id.btn_reporte_tecnico);

        btnReporteServicio.setOnClickListener(v -> lanzarReporte("SERVICIO"));
        btnReporteTecnico.setOnClickListener(v -> lanzarReporte("TECNICO"));
    }

    private void lanzarReporte(String tipo) {
        String anioStr = etAnio.getText().toString();
        String mesStr = etMes.getText().toString();

        if (anioStr.isEmpty() || mesStr.isEmpty()) {
            Toast.makeText(this, "Por favor ingrese año y mes.", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(this, ReporteResultadoActivity.class);
        intent.putExtra("TIPO_REPORTE", tipo);
        intent.putExtra("ANIO", Integer.parseInt(anioStr));
        intent.putExtra("MES", Integer.parseInt(mesStr));
        startActivity(intent);
    }
}